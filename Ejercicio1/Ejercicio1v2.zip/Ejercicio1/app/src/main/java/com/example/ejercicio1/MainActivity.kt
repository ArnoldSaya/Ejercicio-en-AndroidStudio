/**
 * Descripción: Actividad principal que maneja los Fragments
 * Autor: Assistant
 * Fecha creación: 24/09/2024
 * Fecha última modificación: 24/09/2024
 */

package com.example.ejercicio1

import android.app.Activity
import android.os.Bundle


class MainActivity : Activity() {

    // Método que se llama cuando se crea la actividad
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) // Llama al método onCreate de la superclase
        setContentView(R.layout.activity_main) // Establece el diseño de la actividad

        // Verifica si es la primera vez que se crea la actividad
        if (savedInstanceState == null) {
            mostrarFragmentoImagen() // Muestra el fragmento de imagen inicial
        }
    }

    // Método para mostrar el fragmento de imagen principal
    fun mostrarFragmentoImagen() {
        fragmentManager.beginTransaction() // Inicia una transacción de fragmento
            .replace(R.id.fragmentContainer, MainFragment()) // Reemplaza el contenido del contenedor con MainFragment
            .commit() // Confirma la transacción
    }

    // Método para mostrar un fragmento de imagen seleccionado
    fun showImageFragment(selectedImage: String) {
        fragmentManager.beginTransaction() // Inicia otra transacción de fragmento
            .replace(R.id.fragmentContainer, ImageFragment.newInstance(selectedImage)) // Reemplaza con ImageFragment, pasando la imagen seleccionada
            .addToBackStack(null) // Agrega la transacción a la pila de retroceso
            .commit() // Confirma la transacción
    }
}
