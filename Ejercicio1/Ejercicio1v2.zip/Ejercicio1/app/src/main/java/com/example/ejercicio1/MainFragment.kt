package com.example.ejercicio1;

/*
Crea una aplicación Android con un Spinner para seleccionar nombres de imágenes
 y un botón "Siguiente" que muestre la imagen seleccionada en una
 nueva actividad. La segunda interfaz tendrá un botón "Volver" que retorne
 a la primera actividad manteniendo la selección del Spinner, incluso al cambiar
 la orientación del dispositivo.

 Autor: Arnold Daniel Saya Ramos
 fecha inicio: 25/09/2024
 fecha fin: 25/09/2024



 */

import android.app.Fragment
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner

class MainFragment : Fragment() {
    // Declaración de variables para el Spinner y el botón
    private lateinit var spinner: Spinner
    private lateinit var nextButton: Button

    // Método para inflar el layout del fragmento
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Infla el layout correspondiente al fragmento
        val view = inflater.inflate(R.layout.fragment_main, container, false)

        // Inicializa las vistas de la interfaz desde el layout XML
        spinner = view.findViewById(R.id.imageSpinner)
        nextButton = view.findViewById(R.id.nextButton)

        // Array con los nombres de las imágenes que aparecerán en el Spinner
        val images = arrayOf("Bowser", "Lion Kennedy", "Jefe Maestro", "Kratos", "Joel", "Ethan Winters")

        // Configura el adaptador para el Spinner
        val adapter = ArrayAdapter(activity, android.R.layout.simple_spinner_item, images)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) // Especifica el layout para el menú desplegable
        spinner.adapter = adapter // Asigna el adaptador al Spinner

        // Configura el comportamiento del botón "Next"
        nextButton.setOnClickListener {
            val selectedImage = spinner.selectedItem.toString() // Obtiene la imagen seleccionada
            // Llama a la función de MainActivity para mostrar el fragmento con la imagen seleccionada
            (activity as? MainActivity)?.showImageFragment(selectedImage)
        }

        // Retorna la vista inflada para este fragmento
        return view
    }
}
