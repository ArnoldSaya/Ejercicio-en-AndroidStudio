package com.example.ejercicio1

/*
Crea una aplicación Android con un Spinner para seleccionar nombres de imágenes
 y un botón "Siguiente" que muestre la imagen seleccionada en una
 nueva actividad. La segunda interfaz tendrá un botón "Volver" que retorne
 a la primera actividad manteniendo la selección del Spinner, incluso al cambiar
 la orientación del dispositivo.

 Autor: Arnold Daniel Saya Ramos
 fecha inicio: 25/09/2024
 fecha fin: 25/09/2024



 */

import android.app.Fragment
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView


class ImageFragment : Fragment() {

    // Variables de vista para los elementos de la interfaz
    private lateinit var imageView: ImageView
    private lateinit var backButton: Button
    private lateinit var imageNameText: TextView

    // Método que se llama para crear la vista del fragmento
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Infla el diseño del fragmento
        val view = inflater.inflate(R.layout.fragment_image, container, false)

        // Asigna las vistas a las variables
        imageView = view.findViewById(R.id.selectedImageView)
        backButton = view.findViewById(R.id.backButton)
        imageNameText = view.findViewById(R.id.imageNameText)

        // Obtiene el nombre de la imagen seleccionada de los argumentos
        val selectedImage = arguments?.getString("selectedImage")
        imageNameText.text = selectedImage // Muestra el nombre de la imagen en el TextView

        // Asigna el recurso de imagen correspondiente según el nombre de la imagen seleccionada
        val imageResource = when(selectedImage) {
            "Bowser" -> R.drawable.browser
            "Ethan Winter" -> R.drawable.ethan
            "Joel" -> R.drawable.joel
            "Kratos" -> R.drawable.kratos
            "Lion" -> R.drawable.lion
            "Jefe Maestro" -> R.drawable.master
            else -> R.drawable.imagen_fondo // Imagen predeterminada
        }
        imageView.setImageResource(imageResource) // Establece la imagen en el ImageView

        // Configura el listener para el botón de retroceso
        backButton.setOnClickListener {
            activity?.fragmentManager?.popBackStack() // Regresa al fragmento anterior
        }

        return view // Devuelve la vista inflada
    }

    // Método estático para crear una nueva instancia de ImageFragment
    companion object {
        fun newInstance(selectedImage: String): ImageFragment {
            val fragment = ImageFragment() // Crea una nueva instancia de ImageFragment
            val args = Bundle() // Crea un nuevo Bundle para pasar argumentos
            args.putString("selectedImage", selectedImage) // Agrega el nombre de la imagen seleccionada
            fragment.arguments = args // Establece los argumentos en el fragmento
            return fragment // Devuelve la nueva instancia del fragmento
        }
    }
}

