package com.example.ejercicio1
/*
Crea una aplicación Android con un Spinner para seleccionar nombres de imágenes
 y un botón "Siguiente" que muestre la imagen seleccionada en una
 nueva actividad. La segunda interfaz tendrá un botón "Volver" que retorne
 a la primera actividad manteniendo la selección del Spinner, incluso al cambiar
 la orientación del dispositivo.

 Autor: Arnold Daniel Saya Ramos
 fecha inicio: 16/09/2024
 fecha fin: 16/09/2024



 */

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class ImageActivity : Activity() {
    // Declaración de variables para los elementos de la interfaz
    private lateinit var imageView: ImageView
    private lateinit var backButton: Button
    private lateinit var imageNameText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image)

        // Inicializa las vistas desde el diseño XML
        imageView = findViewById(R.id.selectedImageView)
        backButton = findViewById(R.id.backButton)
        imageNameText = findViewById(R.id.imageNameText)

        // Obtiene el nombre de la imagen seleccionada pasado a través de un Intent
        val selectedImage = intent.getStringExtra("selectedImage")
        imageNameText.text = selectedImage

        // Asigna la imagen correspondiente en función del nombre seleccionado
        val imageResource = when (selectedImage) {
            "Lion Kennedy" -> R.drawable.lion
            "Kratos" -> R.drawable.kratos
            "Joel" -> R.drawable.joel
            "Jefe Maestro" -> R.drawable.master
            "Bowser" -> R.drawable.browser
            "Ethan Winters" -> R.drawable.ethan
            else -> R.drawable.imagen_fondo // Imagen por defecto si no coincide
        }
        imageView.setImageResource(imageResource)

        // Configura el botón para cerrar la actividad y regresar a la anterior
        backButton.setOnClickListener {
            finish()
        }
    }
}
