package com.example.ejercicio1
/*
Crea una aplicación Android con un Spinner para seleccionar nombres de imágenes
 y un botón "Siguiente" que muestre la imagen seleccionada en una
 nueva actividad. La segunda interfaz tendrá un botón "Volver" que retorne
 a la primera actividad manteniendo la selección del Spinner, incluso al cambiar
 la orientación del dispositivo.

 Autor: Arnold Daniel Saya Ramos
 fecha inicio: 16/09/2024
 fecha fin: 16/09/2024

 */
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner

class MainActivity : Activity() {
    private lateinit var spinner: Spinner
    private lateinit var nextButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinner = findViewById(R.id.imageSpinner)
        nextButton = findViewById(R.id.nextButton)

        val images = arrayOf("Bowser", "Lion Kennedy", "Jefe Maestro", "Kratos", "Joel", "Ethan Winters")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, images)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        nextButton.setOnClickListener {
            val intent = Intent(this, ImageActivity::class.java)
            intent.putExtra("selectedImage", spinner.selectedItem.toString())
            startActivity(intent)
        }
    }
}